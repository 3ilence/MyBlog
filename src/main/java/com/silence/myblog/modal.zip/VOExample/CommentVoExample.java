package com.silence.myblog.modal.VOExample;

/**
 * @ClassName : CommentVOExample
 * @Author : Silence
 * @Date: 2021/6/14 13:12
 * @Description :
 */
public class CommentVoExample {
}
