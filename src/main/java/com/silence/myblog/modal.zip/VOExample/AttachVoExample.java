package com.silence.myblog.modal.VOExample;

/**
 * @ClassName : AttachVoExample
 * @Author : Silence
 * @Date: 2021/6/14 13:12
 * @Description :
 */
public class AttachVoExample {
}
