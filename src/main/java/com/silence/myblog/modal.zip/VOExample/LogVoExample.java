package com.silence.myblog.modal.VOExample;

/**
 * @ClassName : LogVoExample
 * @Author : Silence
 * @Date: 2021/6/14 13:13
 * @Description :
 */
public class LogVoExample {
}
