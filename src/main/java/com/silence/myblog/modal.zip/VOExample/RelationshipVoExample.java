package com.silence.myblog.modal.VOExample;

/**
 * @ClassName : RelationshipVoExample
 * @Author : Silence
 * @Date: 2021/6/14 13:14
 * @Description :
 */
public class RelationshipVoExample {
}
