package com.silence.myblog.modal.Bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @ClassName : StatisticsBo
 * @Author : Silence
 * @Date: 2021/6/14 11:54
 * @Description : 后台统计对象
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatisticsBo implements Serializable {
    /***/
    private Long articles;

    /***/
    private Long comments;

    /***/
    private Long links;

    /***/
    private Long attachs;
}
