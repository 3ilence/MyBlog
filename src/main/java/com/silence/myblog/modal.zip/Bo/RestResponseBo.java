package com.silence.myblog.modal.Bo;

import lombok.Data;

/**
 * @ClassName : RestResponseBo
 * @Author : Silence
 * @Date: 2021/6/14 11:54
 * @Description : rest返回对象
 */
@Data
public class RestResponseBo<T> {
    /**服务器响应数据*/
    private T payload;

    /**请求是否成功*/
    private boolean success;

    /**错误信息*/
    private String msg;

    /**状态码*/
    private int code = -1;

    /**服务器响应时间*/
    private long timestamp;

    public RestResponseBo() {
        this.timestamp = System.currentTimeMillis() / 1000;
    }

    public RestResponseBo(boolean success) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
    }

    public RestResponseBo(boolean success, T payload) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.payload = payload;
    }

    public RestResponseBo(boolean success, T payload, int code) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.payload = payload;
        this.code = code;
    }

    public RestResponseBo(boolean success, String msg) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.msg = msg;
    }

    public RestResponseBo(boolean success, String msg, int code) {
        this.timestamp = System.currentTimeMillis() / 1000;
        this.success = success;
        this.msg = msg;
        this.code = code;
    }

    /**
     * 返回没有负载数据的空响应
     * @return 响应成功时返回的包装后的响应体
     */
    public static RestResponseBo ok() {
        return new RestResponseBo(true);
    }

    /**
     * 返回有负载数据的响应
     * @param payload 待包装的数据
     * @param <T> 响应数据的类型
     * @return 响应成功时返回的包装后的响应体
     */
    public static <T> RestResponseBo ok(T payload) {
        return new RestResponseBo(true, payload);
    }

    /**
     * 
     * @param code 响应状态码
     * @param <T> 负载数据类型
     * @return 响应成功时返回的包装后的响应体
     */
    public static <T> RestResponseBo ok(int code) {
        return new RestResponseBo(true, null, code);
    }


    /**
     *
     * @param payload
     * @param code
     * @param <T>
     * @return 响应成功时返回的包装后的响应体
     */
    public static <T> RestResponseBo ok(T payload, int code) {
        return new RestResponseBo(true, payload, code);
    }


    /**
     * 返回空的响应失败响应体
     * @return 响应失败时返回的包装后的响应体
     */
    public static RestResponseBo fail() {
        return new RestResponseBo(false);
    }

    /**
     * 返回包含错误信息的响应失败响应体
     * @param msg
     * @return 响应失败时返回的包装后的响应体
     */
    public static RestResponseBo fail(String msg) {
        return new RestResponseBo(false, msg);
    }

    /**
     * 返回包含错误状态码信息的响应体
     * @param code
     * @return 响应失败时返回的包装后的响应体
     */
    public static RestResponseBo fail(int code) {
        return new RestResponseBo(false, null, code);
    }


    /**
     *
     * @param code
     * @param msg
     * @return 响应失败时返回的包装后的响应体
     */
    public static RestResponseBo fail(int code, String msg) {
        return new RestResponseBo(false, msg, code);
    }

}
