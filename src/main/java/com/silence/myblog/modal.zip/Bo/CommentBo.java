package com.silence.myblog.modal.Bo;

import com.silence.myblog.modal.Vo.CommentVo;
import lombok.Data;

import java.util.List;

/**
 * @ClassName : CommentBo
 * @Author : Silence
 * @Date: 2021/6/14 11:54
 * @Description : 返回页面的评论，包含父子平路内容
 */
@Data
public class CommentBo extends CommentVo {
    /**评论层级*/
    private int levels;

    /**子评论对象列表*/
    private List<CommentVo> children;

    public CommentBo(CommentVo comments) {
        setAuthor(comments.getAuthor());
        setMail(comments.getMail());
        setCoid(comments.getCoid());
        setAuthorId(comments.getAuthorId());
        setUrl(comments.getUrl());
        setCreated(comments.getCreated());
        setAgent(comments.getAgent());
        setIp(comments.getIp());
        setContent(comments.getContent());
        setOwnerId(comments.getOwnerId());
        setCid(comments.getCid());
    }


}
