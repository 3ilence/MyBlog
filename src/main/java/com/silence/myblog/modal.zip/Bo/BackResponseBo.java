package com.silence.myblog.modal.Bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName : BackResponseBo
 * @Author : Silence
 * @Date: 2021/6/14 11:54
 * @Description :
 */
@Data
public class BackResponseBo implements Serializable {
    /***/
    private String attachPath;

    /***/
    private String themePath;

    /***/
    private String sqlPath;
}
