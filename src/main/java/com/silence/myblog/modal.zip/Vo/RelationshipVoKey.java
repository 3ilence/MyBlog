package com.silence.myblog.modal.Vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @ClassName : RelationshipVoKey
 * @Author : Silence
 * @Date: 2021/6/13 11:19
 * @Description :
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RelationshipVoKey implements Serializable {
    /**
     * 内容主键
     */
    private Integer cid;

    /**
     * 项目主键
     */
    private Integer mid;

    private static final long serialVersionUID = 1L;

}
