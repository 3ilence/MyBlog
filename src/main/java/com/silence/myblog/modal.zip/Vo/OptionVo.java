package com.silence.myblog.modal.Vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @ClassName : OptionVo
 * @Author : Silence
 * @Date: 2021/6/13 11:05
 * @Description : 配置信息实体类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OptionVo implements Serializable {

    /**配置名称*/
    private String name;

   /**配置值*/
    private String value;

    /**配置描述*/
    private String description;

    private static final long serialVersionUID = 1L;
}
