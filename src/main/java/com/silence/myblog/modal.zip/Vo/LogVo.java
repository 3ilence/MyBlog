package com.silence.myblog.modal.Vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @ClassName : LogVo
 * @Author : Silence
 * @Date: 2021/6/13 11:05
 * @Description :
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogVo implements Serializable {
    /**日志id，主码*/
    private Integer id;

    /**产生的动作*/
    private String action;

    /**产生的数据*/
    private String data;

    /**发生人id*/
    private Integer authorId;

    /**日志产生的ip*/
    private String ip;

    /**日志创建时间*/
    private Integer created;

    private static final long serialVersionUID = 1L;
}
