package com.silence.myblog.modal.Vo;

import java.io.Serializable;

/**
 * @ClassName : AttachVo
 * @Author : Silence
 * @Date: 2021/6/13 10:59
 * @Description :
 */
public class AttachVo implements Serializable {
    /***/
    private Integer id;

    /***/
    private String fname;

    /***/
    private String ftype;

    /***/
    private String fkey;

    /***/
    private Integer authorId;

    /***/
    private Integer created;

    private static final long serialVersionUID = 1L;
}
