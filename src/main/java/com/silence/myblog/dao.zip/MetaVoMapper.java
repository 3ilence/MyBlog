package com.silence.myblog.dao;

/**
 * @ClassName : MetaVoMapper
 * @Author : Silence
 * @Date: 2021/6/14 13:05
 * @Description :
 */
public interface MetaVoMapper {
}
