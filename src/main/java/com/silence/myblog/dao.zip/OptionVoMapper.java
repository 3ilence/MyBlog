package com.silence.myblog.dao;

/**
 * @ClassName : OptionVoMapper
 * @Author : Silence
 * @Date: 2021/6/14 13:05
 * @Description :
 */
public interface OptionVoMapper {
}
