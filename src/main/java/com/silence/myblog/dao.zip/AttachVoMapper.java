package com.silence.myblog.dao;

/**
 * @ClassName : AttachVoMapper
 * @Author : Silence
 * @Date: 2021/6/14 13:06
 * @Description :
 */
public interface AttachVoMapper {
}
