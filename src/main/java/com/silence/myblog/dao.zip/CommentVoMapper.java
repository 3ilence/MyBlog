package com.silence.myblog.dao;

/**
 * @ClassName : CommentVoMapper
 * @Author : Silence
 * @Date: 2021/6/14 13:06
 * @Description :
 */
public interface CommentVoMapper {
}
