package com.silence.myblog.dao;

/**
 * @ClassName : LogVoMapper
 * @Author : Silence
 * @Date: 2021/6/14 13:05
 * @Description :
 */
public interface LogVoMapper {
}
