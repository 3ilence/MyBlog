package com.silence.myblog.dao;

import org.apache.ibatis.annotations.Mapper;

/**
 * @ClassName : UserVoMapper
 * @Author : Silence
 * @Date: 2021/6/14 13:04
 * @Description :
 */
@Mapper
public interface UserVoMapper {

}
